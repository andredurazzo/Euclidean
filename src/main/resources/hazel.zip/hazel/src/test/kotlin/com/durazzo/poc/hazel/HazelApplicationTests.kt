package com.durazzo.poc.hazel

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class HazelApplicationTests {

	@Test
	fun contextLoads() {
	}

}
