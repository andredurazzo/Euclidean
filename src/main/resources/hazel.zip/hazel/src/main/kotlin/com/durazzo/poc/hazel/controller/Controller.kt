package com.durazzo.poc.hazel.controller

import com.durazzo.poc.hazel.service.Cache
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController
import java.time.LocalDateTime

@RestController
@RequestMapping(value = ["/controller"])
class Controller {
    @Autowired lateinit var cache: Cache


    @GetMapping(path = ["/teste/teste"])
    fun getTeste() = LocalDateTime.now()

    @GetMapping(path = ["{key}"])
    fun getStuff(@PathVariable("key") key: String) = cache.getUUID(key)

    @GetMapping(path = ["/cache/listAll"])
    fun clearCache() = cache.listAllCache()
}
