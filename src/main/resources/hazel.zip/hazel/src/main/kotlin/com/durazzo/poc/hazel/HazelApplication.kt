package com.durazzo.poc.hazel

import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication
import org.springframework.cache.annotation.EnableCaching

@SpringBootApplication
@EnableAutoConfiguration
@EnableCaching
class HazelApplication

fun main(args: Array<String>) {
	runApplication<HazelApplication>(*args)
}
