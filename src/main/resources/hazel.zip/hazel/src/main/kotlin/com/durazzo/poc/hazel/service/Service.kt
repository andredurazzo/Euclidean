package com.durazzo.poc.hazel.service

import com.hazelcast.core.HazelcastInstance
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.cache.Cache
import org.springframework.cache.CacheManager
import org.springframework.cache.annotation.CacheEvict
import org.springframework.cache.annotation.Cacheable
import org.springframework.stereotype.Service
import java.util.*
import java.util.concurrent.ConcurrentMap


//@CacheConfig(cacheNames = ["cache"])
@Service
class Cache {

    @Autowired
    @Qualifier("hazelCast")
    lateinit var hazelCast: HazelcastInstance

    @Autowired
    @Qualifier("cacheManager")
    lateinit var  cacheManager:CacheManager

    @Cacheable(value =["teste"], key = "#key")
    fun getUUID(key: String): UUID?  {
        Thread.sleep(5000)
        return UUID.randomUUID().also { println("Generated $it") }
    }

    @CacheEvict(allEntries = true)
    fun clearCache() {}

    @CacheEvict(key = "#key", allEntries = true)
    fun clearCacheBy1(key:String) {}


    fun listAllCache(){

        val distributedObjects = hazelCast.distributedObjects
        distributedObjects.forEach {it ->

            val cache: Cache? = cacheManager.getCache(it.name)

            val nativeCache: Map<Any?, Any?>? = cache?.nativeCache as Map<Any?,Any?>

            nativeCache?.map {
                it ->
                println("chave : ${it.key} value: ${it.value}" )
            }
        }

    }
}
