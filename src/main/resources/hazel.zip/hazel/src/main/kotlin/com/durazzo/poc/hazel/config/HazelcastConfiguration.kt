package com.durazzo.poc.hazel.config



import com.hazelcast.config.Config
import com.hazelcast.config.EvictionPolicy
import com.hazelcast.config.MapConfig
import com.hazelcast.core.Hazelcast
import com.hazelcast.spring.cache.HazelcastCacheManager
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration


@Configuration
class HazelcastConfiguration {
    @Bean
    @Qualifier("hazelCast")
    fun hazelCastConfig() =
            Hazelcast.newHazelcastInstance(Config("hazelcast-instance") .apply {
                setProperty("hazelcast.jmx", "true")

                addMapConfig(
                        MapConfig("cache").apply {
                            evictionPolicy = EvictionPolicy.LRU
                            timeToLiveSeconds = 20
                        }
                )
                addMapConfig(
                        MapConfig("teste").apply {
                            evictionPolicy = EvictionPolicy.LRU
                            timeToLiveSeconds = 20
                        }
                )

            })
    @Bean
    @Qualifier("cacheManager")
    fun cacheManager() =  HazelcastCacheManager(hazelCastConfig())

}